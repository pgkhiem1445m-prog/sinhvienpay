import { useState, useEffect, useMemo } from 'react';
import { Transaction, Budget, ALL_CATEGORIES } from '../types';
import { startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';

const STORAGE_KEYS = {
  TRANSACTIONS: 'svpay_transactions',
  BUDGETS: 'svpay_budgets',
  THEME: 'svpay_theme',
};

export function useFinance() {
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    return saved ? JSON.parse(saved) : [];
  });

  const [budgets, setBudgets] = useState<Budget[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BUDGETS);
    return saved ? JSON.parse(saved) : [];
  });

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BUDGETS, JSON.stringify(budgets));
  }, [budgets]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.THEME, isDarkMode ? 'dark' : 'light');
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const addTransaction = (t: Omit<Transaction, 'id'>) => {
    const newTransaction = { ...t, id: crypto.randomUUID() };
    setTransactions(prev => [newTransaction, ...prev]);
  };

  const updateTransaction = (id: string, t: Partial<Transaction>) => {
    setTransactions(prev => prev.map(item => item.id === id ? { ...item, ...t } : item));
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(item => item.id !== id));
  };

  const setBudget = (categoryId: string, amount: number) => {
    setBudgets(prev => {
      const existing = prev.find(b => b.categoryId === categoryId);
      if (existing) {
        return prev.map(b => b.categoryId === categoryId ? { ...b, amount } : b);
      }
      return [...prev, { categoryId, amount }];
    });
  };

  const currentMonthTransactions = useMemo(() => {
    const now = new Date();
    const start = startOfMonth(now);
    const end = endOfMonth(now);
    return transactions.filter(t => 
      isWithinInterval(new Date(t.date), { start, end })
    );
  }, [transactions]);

  const stats = useMemo(() => {
    const income = currentMonthTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    const expense = currentMonthTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const totalBalance = transactions.reduce((sum, t) => 
      t.type === 'income' ? sum + t.amount : sum - t.amount, 0
    );

    return { income, expense, totalBalance };
  }, [transactions, currentMonthTransactions]);

  const categorySpending = useMemo(() => {
    const spending: Record<string, number> = {};
    currentMonthTransactions
      .filter(t => t.type === 'expense')
      .forEach(t => {
        spending[t.categoryId] = (spending[t.categoryId] || 0) + t.amount;
      });
    return spending;
  }, [currentMonthTransactions]);

  const budgetAlerts = useMemo(() => {
    return budgets.filter(b => {
      const spent = categorySpending[b.categoryId] || 0;
      return spent > b.amount;
    }).map(b => {
      const category = ALL_CATEGORIES.find(c => c.id === b.categoryId);
      return {
        categoryId: b.categoryId,
        categoryName: category?.name || 'Unknown',
        amount: b.amount,
        spent: categorySpending[b.categoryId] || 0
      };
    });
  }, [budgets, categorySpending]);

  return {
    transactions,
    budgets,
    isDarkMode,
    toggleDarkMode: () => setIsDarkMode(!isDarkMode),
    addTransaction,
    updateTransaction,
    deleteTransaction,
    setBudget,
    stats,
    currentMonthTransactions,
    categorySpending,
    budgetAlerts
  };
}
