export type TransactionType = 'income' | 'expense';
export type TransactionTerm = 'short' | 'long';

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  type: TransactionType;
}

export interface Transaction {
  id: string;
  amount: number;
  type: TransactionType;
  categoryId: string;
  date: string; // ISO string
  note: string;
  term?: TransactionTerm;
}

export interface Budget {
  categoryId: string;
  amount: number;
}

export const INCOME_CATEGORIES: Category[] = [
  { id: 'inc-1', name: 'Lương', icon: 'Briefcase', color: '#10b981', type: 'income' },
  { id: 'inc-2', name: 'Làm thêm', icon: 'Clock', color: '#3b82f6', type: 'income' },
  { id: 'inc-3', name: 'Trợ cấp', icon: 'Heart', color: '#f59e0b', type: 'income' },
  { id: 'inc-4', name: 'Khác', icon: 'Plus', color: '#6b7280', type: 'income' },
];

export const EXPENSE_CATEGORIES: Category[] = [
  { id: 'exp-1', name: 'Ăn uống', icon: 'Utensils', color: '#ef4444', type: 'expense' },
  { id: 'exp-2', name: 'Học tập', icon: 'Book', color: '#8b5cf6', type: 'expense' },
  { id: 'exp-3', name: 'Giải trí', icon: 'Gamepad2', color: '#ec4899', type: 'expense' },
  { id: 'exp-4', name: 'Đi lại', icon: 'Car', color: '#f97316', type: 'expense' },
  { id: 'exp-5', name: 'Nhà cửa', icon: 'Home', color: '#06b6d4', type: 'expense' },
  { id: 'exp-6', name: 'Mua sắm', icon: 'ShoppingBag', color: '#d946ef', type: 'expense' },
  { id: 'exp-7', name: 'Sức khỏe', icon: 'Stethoscope', color: '#10b981', type: 'expense' },
  { id: 'exp-8', name: 'Khác', icon: 'MoreHorizontal', color: '#6b7280', type: 'expense' },
];

export const ALL_CATEGORIES = [...INCOME_CATEGORIES, ...EXPENSE_CATEGORIES];
