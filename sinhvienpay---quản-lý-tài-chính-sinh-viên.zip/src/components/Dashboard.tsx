import React from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Plus, 
  ArrowRight,
  AlertCircle,
  Zap,
  Clock
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';
import { formatCurrency, formatDate } from '../utils/format';
import { Transaction, ALL_CATEGORIES } from '../types';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface DashboardProps {
  stats: { income: number; expense: number; totalBalance: number };
  transactions: Transaction[];
  categorySpending: Record<string, number>;
  budgetAlerts: any[];
  onAddTransaction: () => void;
}

export function Dashboard({ stats, transactions, categorySpending, budgetAlerts, onAddTransaction }: DashboardProps) {
  const recentTransactions = transactions.slice(0, 5);

  const shortTermSpending = transactions
    .filter(t => t.type === 'expense' && t.term === 'short')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const longTermSpending = transactions
    .filter(t => t.type === 'expense' && t.term === 'long')
    .reduce((sum, t) => sum + t.amount, 0);

  const pieData = Object.entries(categorySpending).map(([id, amount]) => {
    const category = ALL_CATEGORIES.find(c => c.id === id);
    return {
      name: category?.name || 'Khác',
      value: amount,
      color: category?.color || '#6b7280'
    };
  });

  // Mock data for bar chart (last 7 days)
  const barData = [
    { name: 'T2', thu: 400000, chi: 240000 },
    { name: 'T3', thu: 300000, chi: 139800 },
    { name: 'T4', thu: 200000, chi: 980000 },
    { name: 'T5', thu: 278000, chi: 390800 },
    { name: 'T6', thu: 189000, chi: 480000 },
    { name: 'T7', thu: 239000, chi: 380000 },
    { name: 'CN', thu: 349000, chi: 430000 },
  ];

  return (
    <div className="space-y-8 pb-20 md:pb-0">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Chào bạn! 👋</h1>
          <p className="text-slate-500 dark:text-slate-400">Hôm nay bạn đã chi tiêu gì chưa?</p>
        </div>
        <button 
          onClick={onAddTransaction}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-2xl font-semibold shadow-lg shadow-indigo-200 dark:shadow-none transition-all active:scale-95"
        >
          <Plus size={20} />
          Thêm giao dịch
        </button>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          title="Tổng số dư" 
          amount={stats.totalBalance} 
          icon={Wallet} 
          color="indigo" 
          delay={0}
        />
        <StatCard 
          title="Thu nhập tháng này" 
          amount={stats.income} 
          icon={TrendingUp} 
          color="emerald" 
          delay={0.1}
        />
        <StatCard 
          title="Chi tiêu tháng này" 
          amount={stats.expense} 
          icon={TrendingDown} 
          color="rose" 
          delay={0.2}
        />
      </div>

      {/* Term Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center">
              <Zap size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Chi tiêu ngắn hạn</p>
              <p className="font-bold">{formatCurrency(shortTermSpending)}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-bold text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded-full uppercase">Hàng ngày</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center">
              <Clock size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Chi tiêu dài hạn</p>
              <p className="font-bold">{formatCurrency(longTermSpending)}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-bold text-blue-600 bg-blue-50 dark:bg-blue-900/20 px-2 py-0.5 rounded-full uppercase">Đầu tư/Lớn</p>
          </div>
        </div>
      </div>

      {budgetAlerts.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-4 rounded-2xl flex items-start gap-3"
        >
          <AlertCircle className="text-amber-500 shrink-0 mt-0.5" size={20} />
          <div>
            <h3 className="font-semibold text-amber-800 dark:text-amber-200">Cảnh báo ngân sách!</h3>
            <p className="text-sm text-amber-700 dark:text-amber-300">
              Bạn đã chi vượt ngân sách ở {budgetAlerts.length} danh mục. Hãy kiểm tra lại nhé!
            </p>
          </div>
        </motion.div>
      )}

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-sm">
          <h3 className="text-lg font-bold mb-6">Thống kê thu chi tuần này</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <YAxis hide />
                <Tooltip 
                  cursor={{ fill: '#f1f5f9' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="thu" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="chi" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-sm">
          <h3 className="text-lg font-bold mb-6">Cơ cấu chi tiêu</h3>
          <div className="h-[300px] w-full">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400">
                <TrendingDown size={48} strokeWidth={1} className="mb-2" />
                <p>Chưa có dữ liệu chi tiêu</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-6 flex items-center justify-between border-b dark:border-slate-800">
          <h3 className="text-lg font-bold">Giao dịch gần đây</h3>
          <button className="text-indigo-600 font-semibold text-sm flex items-center gap-1 hover:underline">
            Xem tất cả <ArrowRight size={16} />
          </button>
        </div>
        <div className="divide-y dark:divide-slate-800">
          {recentTransactions.length > 0 ? (
            recentTransactions.map((t, idx) => {
              const category = ALL_CATEGORIES.find(c => c.id === t.categoryId);
              return (
                <div key={t.id} className="p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-white"
                      style={{ backgroundColor: category?.color || '#6b7280' }}
                    >
                      <Plus size={20} />
                    </div>
                    <div>
                      <p className="font-bold">{category?.name || 'Khác'}</p>
                      <p className="text-xs text-slate-500">{formatDate(t.date)} • {t.note || 'Không có ghi chú'}</p>
                    </div>
                  </div>
                  <p className={cn(
                    "font-bold text-lg",
                    t.type === 'income' ? "text-emerald-600" : "text-rose-600"
                  )}>
                    {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount)}
                  </p>
                </div>
              );
            })
          ) : (
            <div className="p-12 text-center text-slate-400">
              Chưa có giao dịch nào.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, amount, icon: Icon, color, delay }: { title: string; amount: number; icon: any; color: string; delay: number }) {
  const colors: Record<string, string> = {
    indigo: "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400",
    emerald: "bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400",
    rose: "bg-rose-50 text-rose-600 dark:bg-rose-900/20 dark:text-rose-400",
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-sm flex items-center gap-5"
    >
      <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center", colors[color])}>
        <Icon size={28} />
      </div>
      <div>
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{title}</p>
        <p className="text-2xl font-bold tracking-tight">{formatCurrency(amount)}</p>
      </div>
    </motion.div>
  );
}
