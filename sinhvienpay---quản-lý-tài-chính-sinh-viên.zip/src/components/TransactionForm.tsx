import React, { useState } from 'react';
import { X, Plus, Calendar, FileText, DollarSign, Clock, Zap } from 'lucide-react';
import { Transaction, TransactionType, TransactionTerm, INCOME_CATEGORIES, EXPENSE_CATEGORIES } from '../types';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface TransactionFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (t: Omit<Transaction, 'id'>) => void;
  initialData?: Transaction;
}

export function TransactionForm({ isOpen, onClose, onSubmit, initialData }: TransactionFormProps) {
  const [type, setType] = useState<TransactionType>(initialData?.type || 'expense');
  const [term, setTerm] = useState<TransactionTerm>(initialData?.term || 'short');
  const [amount, setAmount] = useState<string>(initialData?.amount.toString() || '');
  const [categoryId, setCategoryId] = useState<string>(initialData?.categoryId || '');
  const [date, setDate] = useState<string>(initialData?.date || new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState<string>(initialData?.note || '');

  const categories = type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !categoryId || !date) return;
    onSubmit({
      amount: parseFloat(amount),
      type,
      categoryId,
      date,
      note,
      term: type === 'expense' ? term : undefined
    });
    onClose();
    // Reset form
    setAmount('');
    setCategoryId('');
    setNote('');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl overflow-hidden"
          >
            <div className="p-8">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold tracking-tight">
                  {initialData ? 'Sửa giao dịch' : 'Thêm giao dịch mới'}
                </h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Type Selector */}
                <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
                  <button
                    type="button"
                    onClick={() => { setType('expense'); setCategoryId(''); }}
                    className={cn(
                      "flex-1 py-3 rounded-xl font-bold transition-all",
                      type === 'expense' ? "bg-white dark:bg-slate-700 text-rose-600 shadow-sm" : "text-slate-500"
                    )}
                  >
                    Chi tiêu
                  </button>
                  <button
                    type="button"
                    onClick={() => { setType('income'); setCategoryId(''); }}
                    className={cn(
                      "flex-1 py-3 rounded-xl font-bold transition-all",
                      type === 'income' ? "bg-white dark:bg-slate-700 text-emerald-600 shadow-sm" : "text-slate-500"
                    )}
                  >
                    Thu nhập
                  </button>
                </div>

                {/* Term Selector (Only for Expense) */}
                {type === 'expense' && (
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setTerm('short')}
                      className={cn(
                        "flex-1 flex items-center justify-center gap-2 py-2 rounded-xl border-2 transition-all",
                        term === 'short' 
                          ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600" 
                          : "border-transparent bg-slate-50 dark:bg-slate-800 text-slate-500"
                      )}
                    >
                      <Zap size={16} />
                      <span className="font-bold text-sm">Ngắn hạn</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setTerm('long')}
                      className={cn(
                        "flex-1 flex items-center justify-center gap-2 py-2 rounded-xl border-2 transition-all",
                        term === 'long' 
                          ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600" 
                          : "border-transparent bg-slate-50 dark:bg-slate-800 text-slate-500"
                      )}
                    >
                      <Clock size={16} />
                      <span className="font-bold text-sm">Dài hạn</span>
                    </button>
                  </div>
                )}

                {/* Amount Input */}
                <div className="relative">
                  <label className="block text-sm font-semibold text-slate-500 dark:text-slate-400 mb-2 ml-1">Số tiền (VNĐ)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0"
                      className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-2xl py-4 pl-12 pr-4 text-2xl font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                      required
                    />
                  </div>
                </div>

                {/* Category Selector */}
                <div>
                  <label className="block text-sm font-semibold text-slate-500 dark:text-slate-400 mb-2 ml-1">Danh mục</label>
                  <div className="grid grid-cols-4 gap-3 max-h-48 overflow-y-auto p-1">
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setCategoryId(cat.id)}
                        className={cn(
                          "flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition-all",
                          categoryId === cat.id 
                            ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600" 
                            : "border-transparent bg-slate-50 dark:bg-slate-800 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700"
                        )}
                      >
                        <div className="w-8 h-8 flex items-center justify-center">
                          <Plus size={20} />
                        </div>
                        <span className="text-[10px] font-bold text-center leading-tight">{cat.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Date & Note */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative">
                    <label className="block text-sm font-semibold text-slate-500 dark:text-slate-400 mb-2 ml-1">Ngày</label>
                    <div className="relative">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-2xl py-3 pl-11 pr-4 font-medium focus:ring-2 focus:ring-indigo-500 transition-all"
                        required
                      />
                    </div>
                  </div>
                  <div className="relative">
                    <label className="block text-sm font-semibold text-slate-500 dark:text-slate-400 mb-2 ml-1">Ghi chú</label>
                    <div className="relative">
                      <FileText className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input
                        type="text"
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        placeholder="Mua sắm..."
                        className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-2xl py-3 pl-11 pr-4 font-medium focus:ring-2 focus:ring-indigo-500 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-2xl font-bold text-lg shadow-xl shadow-indigo-200 dark:shadow-none transition-all active:scale-[0.98]"
                >
                  {initialData ? 'Lưu thay đổi' : 'Xác nhận giao dịch'}
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
