import React, { useState } from 'react';
import { Search, Filter, Trash2, Edit2, Download } from 'lucide-react';
import { Transaction, ALL_CATEGORIES } from '../types';
import { formatCurrency, formatDate } from '../utils/format';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface TransactionListProps {
  transactions: Transaction[];
  onDelete: (id: string) => void;
  onEdit: (t: Transaction) => void;
}

export function TransactionList({ transactions, onDelete, onEdit }: TransactionListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterTerm, setFilterTerm] = useState<'all' | 'short' | 'long'>('all');

  const filteredTransactions = transactions.filter(t => {
    const category = ALL_CATEGORIES.find(c => c.id === t.categoryId);
    const matchesSearch = (category?.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.note.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = filterType === 'all' || t.type === filterType;
    const matchesCategory = filterCategory === 'all' || t.categoryId === filterCategory;
    const matchesTerm = filterTerm === 'all' || t.term === filterTerm;
    return matchesSearch && matchesType && matchesCategory && matchesTerm;
  });

  const exportToCSV = () => {
    const headers = ['Ngày', 'Loại', 'Thời hạn', 'Danh mục', 'Số tiền', 'Ghi chú'];
    const rows = transactions.map(t => [
      formatDate(t.date),
      t.type === 'income' ? 'Thu nhập' : 'Chi tiêu',
      t.term === 'short' ? 'Ngắn hạn' : (t.term === 'long' ? 'Dài hạn' : ''),
      ALL_CATEGORIES.find(c => c.id === t.categoryId)?.name || 'Khác',
      t.amount,
      t.note
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers, ...rows].map(e => e.join(",")).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "giao_dich_sinhvienpay.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold tracking-tight">Lịch sử giao dịch</h2>
        <button 
          onClick={exportToCSV}
          className="flex items-center justify-center gap-2 bg-white dark:bg-slate-900 border dark:border-slate-800 px-4 py-2 rounded-xl font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
        >
          <Download size={18} />
          Xuất CSV
        </button>
      </header>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="Tìm kiếm giao dịch..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border dark:border-slate-800 rounded-2xl py-3 pl-11 pr-4 focus:ring-2 focus:ring-indigo-500 transition-all"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as any)}
            className="flex-1 bg-white dark:bg-slate-900 border dark:border-slate-800 rounded-2xl py-3 px-4 focus:ring-2 focus:ring-indigo-500 transition-all appearance-none"
          >
            <option value="all">Tất cả loại</option>
            <option value="income">Thu nhập</option>
            <option value="expense">Chi tiêu</option>
          </select>
          <select
            value={filterTerm}
            onChange={(e) => setFilterTerm(e.target.value as any)}
            className="flex-1 bg-white dark:bg-slate-900 border dark:border-slate-800 rounded-2xl py-3 px-4 focus:ring-2 focus:ring-indigo-500 transition-all appearance-none"
          >
            <option value="all">Tất cả thời hạn</option>
            <option value="short">Ngắn hạn</option>
            <option value="long">Dài hạn</option>
          </select>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="flex-1 bg-white dark:bg-slate-900 border dark:border-slate-800 rounded-2xl py-3 px-4 focus:ring-2 focus:ring-indigo-500 transition-all appearance-none"
          >
            <option value="all">Tất cả danh mục</option>
            {ALL_CATEGORIES.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* List */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="divide-y dark:divide-slate-800">
          {filteredTransactions.length > 0 ? (
            filteredTransactions.map((t, idx) => {
              const category = ALL_CATEGORIES.find(c => c.id === t.categoryId);
              return (
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  key={t.id} 
                  className="p-4 flex items-center justify-between group hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-white"
                      style={{ backgroundColor: category?.color || '#6b7280' }}
                    >
                      <Edit2 size={20} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-bold">{category?.name || 'Khác'}</p>
                        {t.term && (
                          <span className={cn(
                            "text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider",
                            t.term === 'short' ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400" : "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                          )}>
                            {t.term === 'short' ? 'Ngắn hạn' : 'Dài hạn'}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">{formatDate(t.date)} • {t.note || 'Không có ghi chú'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <p className={cn(
                      "font-bold text-lg",
                      t.type === 'income' ? "text-emerald-600" : "text-rose-600"
                    )}>
                      {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount)}
                    </p>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => onEdit(t)}
                        className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => onDelete(t.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-all"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })
          ) : (
            <div className="p-20 text-center text-slate-400 flex flex-col items-center gap-4">
              <Filter size={48} strokeWidth={1} />
              <p>Không tìm thấy giao dịch nào phù hợp.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
