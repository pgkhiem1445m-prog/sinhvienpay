import React, { useState } from 'react';
import { Wallet, Plus, AlertCircle, Edit3 } from 'lucide-react';
import { Budget, EXPENSE_CATEGORIES } from '../types';
import { formatCurrency } from '../utils/format';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface BudgetManagerProps {
  budgets: Budget[];
  categorySpending: Record<string, number>;
  onSetBudget: (categoryId: string, amount: number) => void;
}

export function BudgetManager({ budgets, categorySpending, onSetBudget }: BudgetManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editAmount, setEditAmount] = useState('');

  const handleSave = (categoryId: string) => {
    const amount = parseFloat(editAmount);
    if (!isNaN(amount)) {
      onSetBudget(categoryId, amount);
    }
    setEditingId(null);
    setEditAmount('');
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-2xl font-bold tracking-tight">Quản lý ngân sách</h2>
        <p className="text-slate-500 dark:text-slate-400">Thiết lập giới hạn chi tiêu để quản lý tài chính tốt hơn.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {EXPENSE_CATEGORIES.map((cat) => {
          const budget = budgets.find(b => b.categoryId === cat.id);
          const spent = categorySpending[cat.id] || 0;
          const percent = budget ? Math.min((spent / budget.amount) * 100, 100) : 0;
          const isOver = budget && spent > budget.amount;

          return (
            <motion.div 
              layout
              key={cat.id}
              className="bg-white dark:bg-slate-900 p-6 rounded-3xl border dark:border-slate-800 shadow-sm space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white"
                    style={{ backgroundColor: cat.color }}
                  >
                    <Wallet size={20} />
                  </div>
                  <h4 className="font-bold">{cat.name}</h4>
                </div>
                {editingId === cat.id ? (
                  <div className="flex items-center gap-2">
                    <input
                      autoFocus
                      type="number"
                      value={editAmount}
                      onChange={(e) => setEditAmount(e.target.value)}
                      className="w-24 bg-slate-100 dark:bg-slate-800 border-none rounded-lg px-2 py-1 text-sm font-bold"
                      placeholder="Số tiền"
                    />
                    <button 
                      onClick={() => handleSave(cat.id)}
                      className="text-indigo-600 font-bold text-sm"
                    >
                      Lưu
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => {
                      setEditingId(cat.id);
                      setEditAmount(budget?.amount.toString() || '');
                    }}
                    className="text-slate-400 hover:text-indigo-600 transition-colors"
                  >
                    <Edit3 size={18} />
                  </button>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Đã chi: {formatCurrency(spent)}</span>
                  <span className="font-bold">
                    {budget ? `Hạn mức: ${formatCurrency(budget.amount)}` : 'Chưa đặt hạn mức'}
                  </span>
                </div>
                <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${percent}%` }}
                    className={cn(
                      "h-full rounded-full transition-all duration-500",
                      isOver ? "bg-rose-500" : "bg-indigo-600"
                    )}
                  />
                </div>
                {isOver && (
                  <div className="flex items-center gap-1.5 text-rose-500 text-xs font-bold">
                    <AlertCircle size={14} />
                    <span>Vượt ngân sách {formatCurrency(spent - budget.amount)}</span>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
