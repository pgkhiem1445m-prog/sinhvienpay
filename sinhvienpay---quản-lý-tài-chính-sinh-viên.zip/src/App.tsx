import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { TransactionList } from './components/TransactionList';
import { TransactionForm } from './components/TransactionForm';
import { BudgetManager } from './components/BudgetManager';
import { useFinance } from './hooks/useFinance';
import { Transaction } from './types';

export default function App() {
  const {
    transactions,
    budgets,
    isDarkMode,
    toggleDarkMode,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    setBudget,
    stats,
    categorySpending,
    budgetAlerts
  } = useFinance();

  const [activeTab, setActiveTab] = useState('dashboard');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | undefined>(undefined);

  const handleAddTransaction = (t: Omit<Transaction, 'id'>) => {
    if (editingTransaction) {
      updateTransaction(editingTransaction.id, t);
    } else {
      addTransaction(t);
    }
    setEditingTransaction(undefined);
  };

  const handleEdit = (t: Transaction) => {
    setEditingTransaction(t);
    setIsFormOpen(true);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard 
            stats={stats} 
            transactions={transactions} 
            categorySpending={categorySpending}
            budgetAlerts={budgetAlerts}
            onAddTransaction={() => {
              setEditingTransaction(undefined);
              setIsFormOpen(true);
            }}
          />
        );
      case 'income':
        return (
          <TransactionList 
            transactions={transactions.filter(t => t.type === 'income')} 
            onDelete={deleteTransaction}
            onEdit={handleEdit}
          />
        );
      case 'expense':
        return (
          <TransactionList 
            transactions={transactions.filter(t => t.type === 'expense')} 
            onDelete={deleteTransaction}
            onEdit={handleEdit}
          />
        );
      case 'budget':
        return (
          <BudgetManager 
            budgets={budgets}
            categorySpending={categorySpending}
            onSetBudget={setBudget}
          />
        );
      case 'history':
        return (
          <TransactionList 
            transactions={transactions} 
            onDelete={deleteTransaction}
            onEdit={handleEdit}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Layout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab}
      isDarkMode={isDarkMode}
      toggleDarkMode={toggleDarkMode}
    >
      {renderContent()}
      
      <TransactionForm 
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditingTransaction(undefined);
        }}
        onSubmit={handleAddTransaction}
        initialData={editingTransaction}
      />
    </Layout>
  );
}
