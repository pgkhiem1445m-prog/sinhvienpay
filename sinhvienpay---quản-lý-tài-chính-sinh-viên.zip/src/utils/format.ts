import { format } from 'date-fns';
import { vi } from 'date-fns/locale';

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(amount);
};

export const formatDate = (date: string | Date) => {
  return format(new Date(date), 'dd/MM/yyyy', { locale: vi });
};

export const formatMonth = (date: string | Date) => {
  return format(new Date(date), 'MMMM, yyyy', { locale: vi });
};
